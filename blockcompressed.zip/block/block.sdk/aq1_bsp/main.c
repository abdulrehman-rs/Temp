#include "xparameters.h"
#include "xbasic_types.h"
#include "xil_io.h"
 int main()

 {
u32 store;

store =Xil_In32(XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR);

xil_printf("values=%d\n\r",store);


 }
